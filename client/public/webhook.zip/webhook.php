<?php
// Set the content type to application/json
header('Content-Type: application/json');

// Get the raw POST data
$postData = file_get_contents("php://input");

// Decode the JSON data
$data = json_decode($postData, true);

// Check if the required fields are present
if (isset($data['ArticleID']) && isset($data['ArticleContent']) && isset($data['ClientID'])) {
    // Assign the values to variables
    $articleID = $data['ArticleID'];
    $articleContent = $data['ArticleContent'];
    $clientID = $data['ClientID'];

    // Here you can add code to process the data, such as saving it to a database
    // For this example, we'll just log the data to a file
    $logEntry = "ArticleID: $articleID, ArticleContent: $articleContent, ClientID: $clientID" . PHP_EOL;
    file_put_contents('webhook_log.txt', $logEntry, FILE_APPEND);

    // Send a response back to the client
    $response = array(
        'status' => 'success',
        'message' => 'Data received successfully',
        'receivedData' => $data
    );
    echo json_encode($response);
} else {
    // If the required fields are missing, send an error response
    $response = array(
        'status' => 'error',
        'message' => 'Invalid data received'
    );
    echo json_encode($response);
}
?>